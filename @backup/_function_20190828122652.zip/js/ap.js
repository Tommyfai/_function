$(function() {
  $('.input-checkbox > input').click(function() {
    // alert('d')
  })
})
