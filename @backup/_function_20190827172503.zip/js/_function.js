$(document.body).ready(function(e) {
  $(this).mousedown(function(e) {
    if (e.ctrlKey) {
      if (e.which == 3) {
        window.location.reload()
      }
    }
  })
})
